<template>
  <div>
    Info Cards
  </div>
</template>


<script>
export default {
  
}
</script>


<style scoped>

</style>