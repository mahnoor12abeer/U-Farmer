<template>
  <!-- Content Section -->
  <div class="">
    <b-container fluid class="content-section">
      <b-row no-gutters class="pt-4">
        <b-col>
          <h1 class="urdu-font text-center pb-3">خریداری</h1>
        </b-col>
      </b-row>
      <b-row no-gutters class="pt-5 justify-content-center">
        <b-col col="4" lg="4" v-for="card in categories" :key="card.id">
          <router-link :to="card.route">
            <ProductCards :product="card"/>
          </router-link>
          <h4 class="urdu-font cards-title pt-2 pb-4">{{card.title}}</h4>
        </b-col>
      </b-row>
    </b-container>
  </div>
</template>

<script>
import ProductCards from './ProductCards';
import {mapGetters} from "vuex"
export default {
  name : 'content',
  components: {
    ProductCards
  },
  data(){
   return {
 
   }
  },
  computed:{
    ...mapGetters('card',['categories'])
  }
}
</script>


<style scoped>
  .cards-title{
    width: 200px;
    text-align: center;
  }

  /* .bg-img{
    background: url('../../public/assets/rice.jpg') no-repeat;
    background-size: cover;
  } */
</style>